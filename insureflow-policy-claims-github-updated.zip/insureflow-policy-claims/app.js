/* InsureFlow front-end demo. Data is stored in this browser only. */
(() => {
  "use strict";
  const $ = (selector, root = document) => root.querySelector(selector);
  const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];
  const money = value => "₹" + Number(value || 0).toLocaleString("en-IN");
  const esc = value => String(value ?? "").replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
  const lineColors = {Motor:"#5c88e5",Health:"#17a785",Life:"#a091ed",Property:"#e8b254",Travel:"#7ab9c8",Commercial:"#c2cad6"};
  const lineTints = {Motor:"#eaf1ff",Health:"#e2f7ef",Life:"#f0edff",Property:"#fff3dc",Travel:"#e5f5f8",Commercial:"#edf0f4"};
  const lineIcons = {Motor:"🚘",Health:"♡",Life:"♙",Property:"⌂",Travel:"✈",Commercial:"▦"};
  const defaults = {
    policies:[
      {id:"POL-2026-1042",name:"Arun Kumar",line:"Motor",premium:18500,start:"01 Jan 2026",status:"Active",email:"arun.kumar@example.com"},
      {id:"POL-2026-1043",name:"Priya Sharma",line:"Health",premium:24000,start:"05 Feb 2026",status:"Active",email:"priya.sharma@example.com"},
      {id:"POL-2026-1044",name:"Karthik Raj",line:"Life",premium:36000,start:"15 Mar 2026",status:"Pending",email:"karthik.raj@example.com"},
      {id:"POL-2026-1045",name:"Meena Devi",line:"Property",premium:12500,start:"21 Apr 2026",status:"Active",email:"meena.devi@example.com"},
      {id:"POL-2026-1046",name:"Rahul S",line:"Travel",premium:4500,start:"10 Sep 2026",status:"Expired",email:"rahul.s@example.com"}
    ],
    claims:[
      {id:"CLM-2026-0081",name:"Arun Kumar",line:"Motor",amount:45000,date:"18 Oct 2026",status:"Under Review",description:"Vehicle damage"},
      {id:"CLM-2026-0082",name:"Priya Sharma",line:"Health",amount:18500,date:"17 Oct 2026",status:"Approved",description:"Hospital expenses"},
      {id:"CLM-2026-0083",name:"Karthik Raj",line:"Property",amount:125000,date:"16 Oct 2026",status:"Submitted",description:"Property damage"},
      {id:"CLM-2026-0084",name:"Meena Devi",line:"Motor",amount:28000,date:"15 Oct 2026",status:"Rejected",description:"Vehicle damage"},
      {id:"CLM-2026-0085",name:"Rahul S",line:"Health",amount:8500,date:"14 Oct 2026",status:"Under Review",description:"Medical expenses"}
    ]
  };
  let state = loadState();
  let toastTimer;
  let activeModal = null;
  let previousFocus = null;

  function loadState() {
    try {
      const saved = localStorage.getItem("insureflow-demo-v1");
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed.policies) && Array.isArray(parsed.claims)) return parsed;
      }
    } catch (error) { console.warn("Could not load saved demo data", error); }
    return JSON.parse(JSON.stringify(defaults));
  }
  function saveState() {
    try { localStorage.setItem("insureflow-demo-v1", JSON.stringify(state)); }
    catch (error) { showToast("Could not save to browser storage."); }
  }
  function showToast(message) {
    $("#toastMessage").textContent = message;
    $("#toast").classList.remove("hidden");
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => $("#toast").classList.add("hidden"), 3800);
  }
  function statusClass(status) { return "status-" + status.toLowerCase().replace(/\s+/g,"-"); }
  function initials(name) { return name.split(/\s+/).map(s=>s[0]).join("").slice(0,2).toUpperCase(); }
  function lineTag(line) { return `<span class="line-tag"><i class="line-dot" style="background:${lineColors[line]||"#aeb8c6"}"></i>${esc(line)}</span>`; }
  function badge(status) { return `<span class="status ${statusClass(status)}">${esc(status)}</span>`; }
  function updateCounts() {
    $("#policyNavCount").textContent = state.policies.length;
    $("#claimNavCount").textContent = state.claims.length;
    $("#statPolicies").textContent = (1284 + state.policies.length - defaults.policies.length).toLocaleString("en-IN");
    $("#statClaims").textContent = (356 + state.claims.length - defaults.claims.length).toLocaleString("en-IN");
    $("#statPending").textContent = state.claims.filter(c=>["Submitted","Under Review"].includes(c.status)).length + 37;
    $("#donutTotal").textContent = (1284 + state.policies.length - defaults.policies.length).toLocaleString("en-IN");
  }
  function renderPortfolio() {
    const lines = ["Motor","Health","Life","Property","Travel","Commercial"];
    const counts = lines.map(line=>({line,count:state.policies.filter(p=>p.line===line).length}));
    const total = counts.reduce((s,x)=>s+x.count,0) || 1;
    let cursor = 0;
    const stops = counts.map(x=>{const start=cursor;cursor += x.count/total*100;return `${lineColors[x.line]} ${start}% ${cursor}%`;}).join(",");
    $("#portfolioDonut").style.background = `conic-gradient(${stops})`;
    $("#portfolioLegend").innerHTML = counts.map(x=>`<div class="legend-item"><i class="legend-dot" style="background:${lineColors[x.line]}"></i><span>${x.line}</span><strong>${x.count}</strong></div>`).join("");
    $("#insuranceLines").innerHTML = lines.map(line=>`<div class="insurance-line" tabindex="0" role="button" data-line="${line}"><span class="line-icon" style="background:${lineTints[line]};color:${lineColors[line]}">${lineIcons[line]}</span><span class="line-info"><strong>${line} insurance</strong><small>${line==="Motor"?"Vehicle protection":line==="Health"?"Medical coverage":line==="Life"?"Life protection":line==="Property"?"Home & business":line==="Travel"?"Trip protection":"Business coverage"}</small></span><span class="line-count">${state.policies.filter(p=>p.line===line).length}</span></div>`).join("");
  }
  function renderClaimOverview() {
    const count = status => state.claims.filter(c=>c.status===status).length;
    $("#claimSummary").innerHTML = `<div class="claim-summary-card"><strong>${count("Under Review")}</strong><span>Under review</span></div><div class="claim-summary-card"><strong>${count("Approved")}</strong><span>Approved</span></div><div class="claim-summary-card"><strong>${count("Rejected")}</strong><span>Rejected</span></div>`;
    const statuses = [{name:"Submitted",color:"#5c88e5"},{name:"Under Review",color:"#e7b653"},{name:"Approved",color:"#17a785"},{name:"Rejected",color:"#db6b73"},{name:"Settled",color:"#8b78e9"}];
    const max = Math.max(1,...statuses.map(s=>count(s.name)));
    $("#claimBars").innerHTML = statuses.map(s=>`<div class="bar-row"><span>${s.name}</span><div class="bar-track"><div class="bar-fill" style="width:${count(s.name)/max*100}%;background:${s.color}"></div></div><strong class="bar-count">${count(s.name)}</strong></div>`).join("");
  }
  function renderRecentClaims() {
    const list = [...state.claims].slice(0,5);
    $("#recentClaimsBody").innerHTML = list.length ? list.map(c=>`<tr><td class="id-cell">${esc(c.id)}</td><td><span class="customer-cell"><span class="mini-avatar">${initials(c.name)}</span>${esc(c.name)}</span></td><td>${lineTag(c.line)}</td><td class="amount-cell">${money(c.amount)}</td><td>${esc(c.date)}</td><td>${badge(c.status)}</td><td><button class="row-action" aria-label="View claim ${esc(c.id)}" data-claim-detail="${esc(c.id)}">···</button></td></tr>`).join("") : `<tr><td colspan="7"><div class="empty-state">No claims yet. Register a claim to get started.</div></td></tr>`;
  }
  const tasks = [
    {title:"Review submitted property claim",meta:"CLM-2026-0083 · Claims team",priority:"HIGH",status:"Submitted"},
    {title:"Follow up on claims under review",meta:"Claims operations · Today",priority:"MEDIUM",status:"Under Review"},
    {title:"Check pending policy applications",meta:"Policy administration · This week",priority:"MEDIUM",status:"Pending"}
  ];
  const checkedTasks = new Set();
  function renderTasks() {
    $("#taskList").innerHTML = tasks.map((t,i)=>`<div class="task-item"><button class="task-check ${checkedTasks.has(i)?"checked":""}" data-task="${i}" aria-label="${checkedTasks.has(i)?"Mark incomplete":"Complete task"}">${checkedTasks.has(i)?"✓":""}</button><div class="task-text"><strong>${t.title}</strong><small>${t.meta}</small></div><span class="task-priority ${t.priority==="MEDIUM"?"medium":""}">${t.priority}</span></div>`).join("");
    $("#taskCount").textContent = tasks.length-checkedTasks.size;
  }
  function renderPolicyPage() {
    const q = ($("#policySearch")?.value||"").toLowerCase();
    const status = $("#policyStatusFilter")?.value||"All";
    const line = $("#policyLineFilter")?.value||"All";
    const filtered = state.policies.filter(p=>(`${p.id} ${p.name} ${p.line}`.toLowerCase().includes(q))&&(status==="All"||p.status===status)&&(line==="All"||p.line===line));
    const stats = [{label:"Total policies",value:state.policies.length},{label:"Active policies",value:state.policies.filter(p=>p.status==="Active").length},{label:"Pending applications",value:state.policies.filter(p=>p.status==="Pending").length}];
    $("#policyInlineStats").innerHTML = stats.map(s=>`<div class="inline-stat"><span>${s.label}</span><strong>${s.value}</strong></div>`).join("");
    $("#policiesBody").innerHTML = filtered.length ? filtered.map(p=>`<tr><td class="id-cell">${esc(p.id)}</td><td><span class="customer-cell"><span class="mini-avatar">${initials(p.name)}</span>${esc(p.name)}</span></td><td>${lineTag(p.line)}</td><td class="amount-cell">${money(p.premium)}</td><td>${esc(p.start)}</td><td>${badge(p.status)}</td><td><select class="action-select" data-policy-status="${esc(p.id)}" aria-label="Change status for ${esc(p.id)}">${["Active","Pending","Expired"].map(s=>`<option ${p.status===s?"selected":""}>${s}</option>`).join("")}</select></td></tr>`).join("") : `<tr><td colspan="7"><div class="empty-state">No matching policies found.</div></td></tr>`;
    $("#policiesFooter").innerHTML = `<span>Showing ${filtered.length} of ${state.policies.length} policies</span><span>Demo records</span>`;
  }
  function renderClaimPage() {
    const q = ($("#claimSearch")?.value||"").toLowerCase();
    const status = $("#claimStatusFilter")?.value||"All";
    const line = $("#claimLineFilter")?.value||"All";
    const filtered = state.claims.filter(c=>(`${c.id} ${c.name} ${c.line}`.toLowerCase().includes(q))&&(status==="All"||c.status===status)&&(line==="All"||c.line===line));
    const stats = [{label:"Total claims",value:state.claims.length},{label:"Awaiting review",value:state.claims.filter(c=>["Submitted","Under Review"].includes(c.status)).length},{label:"Approved / settled",value:state.claims.filter(c=>["Approved","Settled"].includes(c.status)).length}];
    $("#claimInlineStats").innerHTML = stats.map(s=>`<div class="inline-stat"><span>${s.label}</span><strong>${s.value}</strong></div>`).join("");
    $("#claimsBody").innerHTML = filtered.length ? filtered.map(c=>`<tr><td class="id-cell">${esc(c.id)}</td><td><span class="customer-cell"><span class="mini-avatar">${initials(c.name)}</span>${esc(c.name)}</span></td><td>${lineTag(c.line)}</td><td class="amount-cell">${money(c.amount)}</td><td>${esc(c.date)}</td><td>${badge(c.status)}</td><td><select class="action-select" data-claim-status="${esc(c.id)}" aria-label="Change status for ${esc(c.id)}">${["Submitted","Under Review","Approved","Rejected","Settled"].map(s=>`<option ${c.status===s?"selected":""}>${s}</option>`).join("")}</select></td></tr>`).join("") : `<tr><td colspan="7"><div class="empty-state">No matching claims found.</div></td></tr>`;
    $("#claimsFooter").innerHTML = `<span>Showing ${filtered.length} of ${state.claims.length} claims</span><span>Demo records</span>`;
  }
  function renderCustomers() {
    const q = ($("#customerSearch")?.value||"").toLowerCase();
    const customers = new Map();
    state.policies.forEach(p=>{if(!customers.has(p.name))customers.set(p.name,{name:p.name,email:p.email||"No email recorded",policies:[]});customers.get(p.name).policies.push(p);});
    const list = [...customers.values()].filter(c=>(c.name+" "+c.email).toLowerCase().includes(q));
    $("#customerCount").textContent = `${customers.size} customers`;
    $("#customerGrid").innerHTML = list.length ? list.map(c=>`<article class="customer-card"><div class="customer-card-head"><span class="mini-avatar">${initials(c.name)}</span><div><h3>${esc(c.name)}</h3><p>${esc(c.email)}</p></div></div><div class="customer-meta"><span>Policies</span><strong>${c.policies.length}</strong></div><div class="customer-meta" style="border:0;padding-top:9px;margin-top:0"><span>Insurance lines</span><strong>${[...new Set(c.policies.map(p=>p.line))].join(", ")}</strong></div></article>`).join("") : `<div class="panel empty-state">No customers match your search.</div>`;
  }
  function renderReports() {
    const premium = state.policies.reduce((sum,p)=>sum+Number(p.premium||0),0);
    const claimAmount = state.claims.reduce((sum,c)=>sum+Number(c.amount||0),0);
    const approved = state.claims.filter(c=>["Approved","Settled"].includes(c.status)).length;
    $("#reportPremium").textContent = money(premium);
    $("#reportClaims").textContent = money(claimAmount);
    $("#reportApproval").textContent = `${state.claims.length?Math.round(approved/state.claims.length*100):0}%`;
    const lines = ["Motor","Health","Life","Property","Travel","Commercial"];
    const lineCounts = lines.map(line=>({label:line,value:state.policies.filter(p=>p.line===line).length,color:lineColors[line]}));
    const maxLine = Math.max(1,...lineCounts.map(x=>x.value));
    $("#reportLineChart").innerHTML = lineCounts.map(x=>`<div><div class="hchart-label"><span>${x.label}</span><strong>${x.value}</strong></div><div class="hchart-track"><div class="hchart-fill" style="width:${x.value/maxLine*100}%;background:${x.color}"></div></div></div>`).join("");
    const statuses = ["Submitted","Under Review","Approved","Rejected","Settled"].map((label,i)=>({label,value:state.claims.filter(c=>c.status===label).length,color:["#5c88e5","#e7b653","#17a785","#db6b73","#8b78e9"][i]}));
    const maxStatus = Math.max(1,...statuses.map(x=>x.value));
    $("#reportStatusChart").innerHTML = statuses.map(x=>`<div><div class="hchart-label"><span>${x.label}</span><strong>${x.value}</strong></div><div class="hchart-track"><div class="hchart-fill" style="width:${x.value/maxStatus*100}%;background:${x.color}"></div></div></div>`).join("");
  }
  function renderAll() {
    updateCounts(); renderPortfolio(); renderClaimOverview(); renderRecentClaims(); renderTasks();
    renderPolicyPage(); renderClaimPage(); renderCustomers(); renderReports();
  }
  function navigate(page) {
    const known = ["overview","policies","claims","customers","reports"];
    if (!known.includes(page)) return;
    known.forEach(name=>{ $(`#${name}Page`).classList.toggle("hidden",name!==page); });
    $$(".nav-item").forEach(button=>button.classList.toggle("active",button.dataset.page===page));
    const label = page.charAt(0).toUpperCase()+page.slice(1);
    $("#breadcrumbCurrent").textContent = page==="overview"?"Overview":page==="policies"?"Policies":page==="claims"?"Claims":label;
    $("#sidebar").classList.remove("open");
    window.scrollTo({top:0,behavior:"smooth"});
  }
  function field(name,label,type="text",options=null,full=false,placeholder="") {
    const cls = full ? "field full" : "field";
    let control;
    if (type==="select") control = `<select name="${name}" id="field-${name}" required>${options.map(o=>`<option value="${esc(o)}">${esc(o)}</option>`).join("")}</select>`;
    else if (type==="textarea") control = `<textarea name="${name}" id="field-${name}" placeholder="${esc(placeholder)}"></textarea>`;
    else control = `<input name="${name}" id="field-${name}" type="${type}" ${type==="number"?'min="1" step="1"':''} placeholder="${esc(placeholder)}" ${type==="number"||name==="name"?"required":""}>`;
    return `<div class="${cls}"><label for="field-${name}">${label}</label>${control}</div>`;
  }
  function openModal(kind) {
    activeModal = kind; previousFocus = document.activeElement;
    $("#formError").classList.add("hidden"); $("#formError").textContent="";
    const isPolicy = kind==="policy";
    $("#modalEyebrow").textContent = isPolicy?"POLICY ADMINISTRATION":"CLAIMS OPERATIONS";
    $("#modalTitle").textContent = isPolicy?"Create a policy":"Register a claim";
    $("#modalDescription").textContent = isPolicy?"Add a policyholder and basic policy details to the demo workspace.":"Capture a new claim submission for assessment.";
    $("#modalSubmit").textContent = isPolicy?"Save policy":"Submit claim";
    const lineOptions = ["Motor","Health","Life","Property","Travel","Commercial"];
    const fields = isPolicy
      ? field("name","Policyholder name","text",null,false,"Full name")+field("line","Insurance line","select",lineOptions)+field("premium","Premium amount (₹)","number",null,false,"e.g. 25000")+field("start","Policy start date","date",null,false)
      : field("name","Policyholder name","text",null,false,"Full name")+field("line","Insurance line","select",lineOptions)+field("amount","Claim amount (₹)","number",null,false,"e.g. 25000")+field("date","Submission date","date",null,false)+field("description","Claim description","textarea",null,true,"Briefly describe the incident");
    $("#formFields").innerHTML = fields;
    if (!isPolicy) $("#field-date").value = new Date().toISOString().slice(0,10);
    $("#modalBackdrop").classList.remove("hidden");
    document.body.style.overflow="hidden";
    $("#field-name").focus();
  }
  function closeModal() {
    $("#modalBackdrop").classList.add("hidden"); document.body.style.overflow=""; activeModal=null;
    if(previousFocus?.focus) previousFocus.focus();
  }
  function dateLabel(value) {
    if(!value) return "21 Oct 2026";
    const d = new Date(`${value}T12:00:00`);
    return Number.isNaN(d.getTime())?value:d.toLocaleDateString("en-GB",{day:"2-digit",month:"short",year:"numeric"});
  }
  function nextId(type) {
    const list = type==="policy"?state.policies:state.claims;
    const prefix = type==="policy"?"POL-2026-":"CLM-2026-";
    const nums = list.map(x=>Number(x.id.split("-").at(-1))).filter(Number.isFinite);
    return prefix+String(Math.max(type==="policy"?1041:80,...nums)+1).padStart(4,"0");
  }
  function submitRecord(event) {
    event.preventDefault();
    const form = new FormData(event.currentTarget);
    const name = String(form.get("name")||"").trim();
    const line = String(form.get("line")||"");
    const amount = Number(form.get(activeModal==="policy"?"premium":"amount"));
    const error = $("#formError");
    if(!name || !Number.isFinite(amount)||amount<=0){error.textContent="Enter a customer name and an amount greater than zero.";error.classList.remove("hidden");return;}
    if(activeModal==="policy"){
      state.policies.unshift({id:nextId("policy"),name,line,premium:amount,start:dateLabel(form.get("start")),status:"Active",email:""});
      showToast("Policy created successfully in this demo.");
    } else {
      state.claims.unshift({id:nextId("claim"),name,line,amount,date:dateLabel(form.get("date")),status:"Submitted",description:String(form.get("description")||"").trim()});
      showToast("Claim registered successfully in this demo.");
    }
    saveState(); renderAll(); closeModal();
  }
  function exportClaimsCSV() {
    const rows = [["Claim ID","Policyholder","Insurance line","Amount INR","Date submitted","Status","Description"],...state.claims.map(c=>[c.id,c.name,c.line,c.amount,c.date,c.status,c.description||""])];
    const csv = rows.map(row=>row.map(value=>`"${String(value??"").replace(/"/g,'""')}"`).join(",")).join("\r\n");
    const blob = new Blob(["\uFEFF"+csv],{type:"text/csv;charset=utf-8;"});
    const url = URL.createObjectURL(blob); const a=document.createElement("a");a.href=url;a.download="insureflow-claims-report.csv";document.body.appendChild(a);a.click();a.remove();URL.revokeObjectURL(url);
    showToast("Claims CSV exported.");
  }

  $$(".nav-item").forEach(button=>button.addEventListener("click",()=>navigate(button.dataset.page)));
  $$("[data-goto]").forEach(button=>button.addEventListener("click",()=>navigate(button.dataset.goto)));
  $("#mobileMenu").addEventListener("click",()=>$("#sidebar").classList.toggle("open"));
  $("#addPolicyButton").addEventListener("click",()=>openModal("policy"));
  $("#addClaimButton").addEventListener("click",()=>openModal("claim"));
  $("#quickCreate").addEventListener("click",()=>openModal("policy"));
  $("#modalClose").addEventListener("click",closeModal);
  $("#modalCancel").addEventListener("click",closeModal);
  $("#modalBackdrop").addEventListener("click",event=>{if(event.target===$("#modalBackdrop"))closeModal();});
  $("#recordForm").addEventListener("submit",submitRecord);
  $("#toastClose").addEventListener("click",()=>$("#toast").classList.add("hidden"));
  $("#notificationButton").addEventListener("click",()=>showToast("You’re all caught up in this demo workspace."));
  $("#helpButton").addEventListener("click",()=>showToast("Use the left navigation to manage policies, claims, customers and reports."));
  $("#exportReport").addEventListener("click",exportClaimsCSV);
  ["policySearch","policyStatusFilter","policyLineFilter"].forEach(id=>$("#"+id).addEventListener("input",renderPolicyPage));
  ["claimSearch","claimStatusFilter","claimLineFilter"].forEach(id=>$("#"+id).addEventListener("input",renderClaimPage));
  $("#customerSearch").addEventListener("input",renderCustomers);
  $("#portfolioPeriod").addEventListener("change",event=>showToast(`Portfolio view set to ${event.target.value.toLowerCase()}; figures are demo data.`));
  document.addEventListener("click",event=>{
    const task=event.target.closest("[data-task]");
    if(task){const index=Number(task.dataset.task);checkedTasks.has(index)?checkedTasks.delete(index):checkedTasks.add(index);renderTasks();}
    const policyStatus=event.target.closest("[data-policy-status]");
    if(policyStatus){const id=policyStatus.dataset.policyStatus;const item=state.policies.find(p=>p.id===id);if(item){item.status=policyStatus.value;saveState();renderAll();showToast(`${id} status updated to ${item.status}.`);}}
    const claimStatus=event.target.closest("[data-claim-status]");
    if(claimStatus){const id=claimStatus.dataset.claimStatus;const item=state.claims.find(c=>c.id===id);if(item){item.status=claimStatus.value;saveState();renderAll();showToast(`${id} status updated to ${item.status}.`);}}
    const detail=event.target.closest("[data-claim-detail]");
    if(detail){const item=state.claims.find(c=>c.id===detail.dataset.claimDetail);if(item)showToast(`${item.id}: ${item.description||"No description recorded"} · ${item.status}`);}
    const line=event.target.closest("[data-line]");
    if(line){navigate("policies");$("#policyLineFilter").value=line.dataset.line;renderPolicyPage();}
  });
  document.addEventListener("keydown",event=>{if(event.key==="Escape"&&!$("#modalBackdrop").classList.contains("hidden"))closeModal();if((event.key==="Enter"||event.key===" ")&&event.target.matches(".insurance-line")){event.preventDefault();event.target.click();}});
  renderAll();
})();
