# InsureFlow — Multi-Line Policy & Claims Management

A responsive front-end prototype for a multi-line insurance operations dashboard, built with plain HTML, CSS and JavaScript.

## Project files
- `index.html` — dashboard and application pages
- `styles.css` — responsive styling for desktop, tablet and mobile
- `app.js` — sample policy/claims data, navigation, forms, filters and CSV export
- `.gitignore` — common local development exclusions

## Run locally
1. Extract the project ZIP.
2. Open `insureflow-policy-claims/index.html` in a modern browser.
3. If you want to serve it locally, use VS Code Live Server or any static HTTP server. No build step or package installation is required.

## Publish with GitHub Pages
1. Upload the project files to the repository root (so `index.html`, `styles.css` and `app.js` are all at the root).
2. Open **Settings → Pages**.
3. Under **Build and deployment**, select **Deploy from a branch**.
4. Select branch `main` and folder `/(root)`, then click **Save**.
5. After deployment completes, open the URL shown in the Pages settings.

## Features
- Overview dashboard with portfolio and claims summaries
- Policy creation, search, filtering and status management
- Claim registration, search, filtering and status updates
- Customer directory
- Reports and CSV export
- Responsive layouts

## Important limitations
This is a front-end demo, not a production insurance system. It does not include a secure backend, shared database, authentication, authorization, payments or real insurer integrations. Demo records may be stored in the current browser only and should not be treated as real customer data. Do not enter real customer, health, financial or claim information.
