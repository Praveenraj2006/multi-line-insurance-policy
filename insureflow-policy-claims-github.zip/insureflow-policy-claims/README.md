# InsureFlow — Multi-Line Policy & Claims Management

A responsive front-end prototype for an insurance operations dashboard. Built with plain HTML, CSS and JavaScript, so you can host it on GitHub Pages without installing a framework.

## Features

- Overview dashboard with portfolio and claims summaries
- Multi-line insurance categories: Motor, Health, Life, Property, Travel and Commercial
- Policy creation, searching, filtering and status management
- Claim registration, searching, filtering and status updates
- Customer directory based on policy records
- Reports with visual breakdowns and CSV export
- Browser `localStorage` persistence for demo records
- Responsive desktop, tablet and mobile layouts

## Run locally

1. Download or clone this repository.
2. Open `index.html` in a modern browser.

No build tools, package manager or API keys are required.

## Publish with GitHub Pages

1. Create a repository on GitHub, for example `insureflow-policy-claims`.
2. Upload `index.html`, `styles.css`, `app.js`, `README.md` and `.gitignore` to the repository root.
3. Open **Settings → Pages** in the repository.
4. Under **Build and deployment**, select **Deploy from a branch**.
5. Select branch `main` and folder `/ (root)`, then click **Save**.
6. After GitHub Pages finishes deploying, your site URL will be shown in the Pages section. It usually looks like `https://YOUR-USERNAME.github.io/insureflow-policy-claims/`.

### Push using Git from your computer

Install Git, open a terminal inside this project folder, then run:

```bash
git init
git add .
git commit -m "Build InsureFlow policy and claims dashboard"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/insureflow-policy-claims.git
git push -u origin main
```

Replace `YOUR-USERNAME` with your GitHub username and use the repository URL you created. If the project is already a Git repository, do not run `git init` again.

## Important limitations

This is a **front-end demo**, not a production insurance system. It stores demo records in the current browser only. It has no server, shared database, real authentication, authorization, secure document storage, payments, email notifications, or regulatory integrations. Do not enter real customer, health, financial or claim data. Before production use, add a secured backend, database, role-based access control, audit logging, validation, backups, and appropriate legal/security reviews.

## Reset demo data

Clear the site's local storage for this page in your browser's developer tools to return to the initial sample records.
